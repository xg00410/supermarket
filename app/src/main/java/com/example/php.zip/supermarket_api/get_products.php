<?php
require_once "db_config.php";

header("Content-Type: application/json; charset=utf-8");

// GET パラメータ: store_code=S001 など
$storeId = $_GET["store_code"] ?? null;

if (!$storeId) {
    echo json_encode([
        "status"  => "error",
        "message" => "store_code が指定されていません。"
    ]);
    exit;
}

try {
    $sql = "SELECT product_id, name, category, price, stock
            FROM products
            WHERE store_id = :store_id
            ORDER BY product_id ASC";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(":store_id", $storeId, PDO::PARAM_STR);
    $stmt->execute();

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "ok",
        "data"   => $rows
    ]);
} catch (Exception $e) {
    echo json_encode([
        "status"  => "error",
        "message" => "商品取得中にエラーが発生しました: " . $e->getMessage()
    ]);
}
