<?php
// login.php
require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_code = trim($input['user_code'] ?? '');
$password  = trim($input['password']  ?? '');

if ($user_code === '' || $password === '') {
    echo json_encode([
        'status'  => 'error',
        'id'      => null,
        'user_id' => null,
        'user_code' => null,
        'name'    => null,
        'phone'   => null,
        'email'   => null,
        'message' => 'ユーザーIDとパスワードは必須です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

$stmt = $pdo->prepare(
    'SELECT id, user_code, password, name, phone, email
       FROM users
      WHERE user_code = ?
      LIMIT 1'
);
$stmt->execute([$user_code]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$row || $row['password'] !== $password) {
    echo json_encode([
        'status'    => 'error',
        'id'        => null,
        'user_id'   => null,
        'user_code' => null,
        'name'      => null,
        'phone'     => null,
        'email'     => null,
        'message'   => 'ユーザーIDまたはパスワードが正しくありません。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// ログイン成功：ユーザー情報を返す
echo json_encode([
    'status'    => 'ok',
    'id'        => (int)$row['id'],
    'user_id'   => (int)$row['id'],
    'user_code' => $row['user_code'],
    'name'      => $row['name'] ?? $row['user_code'],
    'phone'     => $row['phone'],
    'email'     => $row['email'],
    'message'   => 'ログイン成功'
], JSON_UNESCAPED_UNICODE);
