<?php
// register.php
require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

// フロントから送られてくる値
$user_code = trim($input['user_code'] ?? '');
$password  = trim($input['password']  ?? '');
$email     = isset($input['email']) ? trim($input['email']) : null;
$name      = isset($input['name'])  ? trim($input['name'])  : null;
$phone     = isset($input['phone']) ? trim($input['phone']) : null;

if ($user_code === '' || $password === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDとパスワードは必須です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // ユーザーID重複チェック
    $stmt = $pdo->prepare('SELECT id FROM users WHERE user_code = ?');
    $stmt->execute([$user_code]);
    if ($stmt->fetch()) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'このユーザーIDは既に登録されています。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // 登録（name / phone / email も含めて保存）
    $stmt = $pdo->prepare(
        'INSERT INTO users (user_code, password, name, phone, email)
         VALUES (?, ?, ?, ?, ?)'
    );
    $stmt->execute([$user_code, $password, $name, $phone, $email]);

    echo json_encode([
        'status'  => 'ok',
        'message' => '登録が完了しました。'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        'status'  => 'error',
        'message' => '登録中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
