<?php
// reset_password.php
// 役割: ユーザーID + メールアドレスを確認し、新しいパスワードに更新する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_code    = trim($input['user_code']    ?? '');
$email        = trim($input['email']        ?? '');
$new_password = trim($input['new_password'] ?? '');

if ($user_code === '' || $email === '' || $new_password === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'すべての項目を入力してください。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $stmt = $pdo->prepare(
        'SELECT id, email FROM users WHERE user_code = ? LIMIT 1'
    );
    $stmt->execute([$user_code]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row || (string)$row['email'] !== $email) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'ユーザーIDまたはメールアドレスが正しくありません。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $stmt = $pdo->prepare(
        'UPDATE users SET password = ? WHERE id = ?'
    );
    $stmt->execute([$new_password, (int)$row['id']]);

    echo json_encode([
        'status'  => 'ok',
        'message' => 'パスワードを更新しました。'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        'status'  => 'error',
        'message' => '更新中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
