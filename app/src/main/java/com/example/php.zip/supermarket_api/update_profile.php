<?php
// update_profile.php
// 役割: ログイン中ユーザーの氏名・電話番号・メールを更新する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_id = (int)($input['user_id'] ?? 0);
$name    = isset($input['name'])  ? trim($input['name'])  : null;
$phone   = isset($input['phone']) ? trim($input['phone']) : null;
$email   = isset($input['email']) ? trim($input['email']) : null;

if ($user_id <= 0) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDが不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $stmt = $pdo->prepare(
        'UPDATE users
            SET name = ?, phone = ?, email = ?
          WHERE id = ?'
    );
    $stmt->execute([$name, $phone, $email, $user_id]);

    echo json_encode([
        'status'  => 'ok',
        'message' => 'プロフィールを更新しました。',
        'user_id' => $user_id,
        'name'    => $name,
        'phone'   => $phone,
        'email'   => $email
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        'status'  => 'error',
        'message' => '更新中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
