package com.example.supermarket.viewmodel

import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.ViewModel
import com.example.supermarket.models.CartItem
import com.example.supermarket.models.HistoryItem
import com.example.supermarket.models.OrderHistoryEntry
import java.time.LocalDateTime

class CartViewModel : ViewModel() {

    // ----------------------------------------------
    // カート内の商品
    // ----------------------------------------------
    private val _cartItems = mutableStateListOf<CartItem>()
    val cartItems: List<CartItem> get() = _cartItems


    // ----------------------------------------------
    // list2（管理画面）のチェック状態
    // ----------------------------------------------
    val selectedItemIds = mutableMapOf<Int, Boolean>()      // 商品 ID → チェックされたか
    val selectedStoreIds = mutableMapOf<String, Boolean>()  // 店舗 ID → チェックされたか
    var isSelectAll = false


    // ----------------------------------------------
    // 注文履歴
    // ----------------------------------------------
    private val _orderHistory = mutableStateListOf<OrderHistoryEntry>()
    val orderHistory: List<OrderHistoryEntry> get() = _orderHistory


    // ============================================================
    //                     カート操作（追加・削除）
    // ============================================================

    fun addToCart(product: CartItem) {
        val existing = _cartItems.find { it.productId == product.productId }
        if (existing != null) {
            existing.quantity += product.quantity
        } else {
            _cartItems.add(product)
        }
    }

    fun increaseQuantity(productId: Int) {
        _cartItems.find { it.productId == productId }?.let {
            it.quantity++
        }
    }

    fun decreaseQuantity(productId: Int) {
        _cartItems.find { it.productId == productId }?.let {
            if (it.quantity > 1) it.quantity--
        }
    }

    fun removeItem(productId: Int) {
        _cartItems.removeAll { it.productId == productId }
    }

    fun totalPrice(): Double =
        _cartItems.sumOf { it.price * it.quantity }


    // ============================================================
    //                     list2（管理画面）チェック機能
    // ============================================================

    /** すべて選択／解除 */
    fun selectAll() {
        isSelectAll = !isSelectAll

        selectedItemIds.clear()
        selectedStoreIds.clear()

        if (isSelectAll) {
            _cartItems.forEach { item ->
                selectedItemIds[item.productId] = true
                selectedStoreIds[item.storeId] = true
            }
        }
    }

    /** 店舗単位のチェック切替 */
    fun toggleStoreChecked(storeId: String) {
        val cur = selectedStoreIds[storeId] ?: false
        selectedStoreIds[storeId] = !cur

        // 店舗の商品をまとめて更新
        _cartItems.filter { it.storeId == storeId }.forEach {
            selectedItemIds[it.productId] = !cur
        }
    }

    /** 商品単位のチェック切替 */
    fun toggleItemChecked(productId: Int) {
        val cur = selectedItemIds[productId] ?: false
        selectedItemIds[productId] = !cur
    }

    /** チェックされた商品を削除 */
    fun deleteSelectedItems() {
        val removeIds = selectedItemIds.filter { it.value }.keys
        _cartItems.removeAll { it.productId in removeIds }

        selectedItemIds.clear()
        selectedStoreIds.clear()
        isSelectAll = false
    }


    // ============================================================
    //                     履歴に保存（最短ルート画面の終了）
    // ============================================================

    fun addHistoryEntry(storeId: String, storeName: String, items: List<CartItem>) {

        val historyItems = items.map {
            HistoryItem(
                productId = it.productId,
                name = it.name,
                quantity = it.quantity,
                price = it.price
            )
        }

        val entry = OrderHistoryEntry(
            storeId = storeId,
            storeName = storeName,
            orderedAt = LocalDateTime.now(),   // API 26+
            items = historyItems
        )

        _orderHistory.add(entry)
    }
}
