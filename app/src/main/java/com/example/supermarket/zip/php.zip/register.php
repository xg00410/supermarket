<?php
// register.php
// 役割: 新規会員登録。
//       フロントから受け取る user_code / name は、DB 上では userid / username に保存する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

// フロントから送られてくる値（Kotlin の RegisterBody）
$user_code = trim($input['user_code'] ?? '');  // DB: users.userid
$password  = trim($input['password']  ?? '');
$email     = isset($input['email']) ? trim($input['email']) : null;
$name      = isset($input['name'])  ? trim($input['name'])  : null; // DB: users.username
$gender    = isset($input['gender']) ? trim($input['gender']) : null; // DB: users.gender
$phone     = isset($input['phone']) ? trim($input['phone']) : null;

// 必須チェック（テスト仕様書に合わせて必須項目を拡張）
if ($user_code === '' || $password === '' || $name === null || trim($name) === '' || $phone === null || trim($phone) === '' || $email === null || trim($email) === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーID、パスワード、氏名、電話番号、メールアドレスは必須です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
// ユーザーID：英数字のみ・長さ（7～50）
if (!preg_match('/^[a-zA-Z0-9]+$/', $user_code) || strlen($user_code) > 50 || strlen($user_code) <= 6) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// パスワード：英数字のみ・長さ（最大255）
// ※強度(8文字以上&英数字混在)はKotlin側で既にチェックしているため、ここは防御的に最小限
if (!preg_match('/^[a-zA-Z0-9]+$/', $password) || strlen($password) > 255) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'パスワードの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 氏名：記号を抑止（日本語で使う「・」「ー」「-」とスペースは許可）
if (strlen($name) > 100 || !preg_match('/^[\p{L}\p{M}0-9\s・ー-]+$/u', $name)) {
    echo json_encode([
        'status'  => 'error',
        'message' => '氏名の形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 電話番号：数字 or ハイフン（Kotlinからはフォーマット済みで届く可能性あり）
if (strlen($phone) > 30 || !preg_match('/^[0-9-]+$/', $phone)) {
    echo json_encode([
        'status'  => 'error',
        'message' => '電話番号の形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// メール：最大100 & 形式
if (strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'メールアドレスの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}


try {
    // 既に同じ userid が存在しないか確認
    $checkSql = "SELECT id FROM users WHERE userid = ?";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute([$user_code]);
    if ($checkStmt->fetch()) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'このユーザーIDは既に使用されています。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

       // users テーブル構造:
    // id, userid, password, username, gender, phone, email
    $insertSql = "
        INSERT INTO users (userid, password, username, gender, phone, email)
        VALUES (?, ?, ?, ?, ?, ?)
    ";
    $stmt = $pdo->prepare($insertSql);

    // 今はパスワードを平文保存（必要に応じて password_hash へ変更可）
    $stmt->execute([$user_code, $password, $name, $gender, $phone, $email]);

    echo json_encode([
        'status'  => 'ok',
        'message' => '登録が完了しました。'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => '登録中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
