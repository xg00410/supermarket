<?php
// db_config.php
header('Content-Type: application/json; charset=UTF-8');

$host = 'localhost';
$db   = 'supermarket';
$user = 'root';
$pass = '';   // XAMPP デフォルトなら空文字

$dsn = "mysql:host=$host;dbname=$db;charset=utf8mb4";

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'DB接続に失敗しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
