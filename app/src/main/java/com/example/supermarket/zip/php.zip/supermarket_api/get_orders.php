<?php
// =========================================================
// File: get_orders.php
// 役割:
//   - 指定ユーザーの注文履歴(orders + order_items)を取得する。
//   - 店舗名・商品名も含めて 1 件の注文ごとにまとめて返す。
// =========================================================

require_once "db_config.php";

header("Content-Type: application/json; charset=utf-8");

$userId = isset($_GET["user_id"]) ? intval($_GET["user_id"]) : 0;
if ($userId <= 0) {
    echo json_encode([
        "status"  => "error",
        "message" => "user_id パラメータが不正です。"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql = "
        SELECT
            o.id         AS order_id,
            o.store_id   AS store_id,
            s.name       AS store_name,
            o.ordered_at AS ordered_at,
            o.total      AS total,

            oi.product_id AS product_id,
            p.name        AS product_name,
            oi.quantity   AS quantity,
            oi.price      AS price
        FROM orders o
        INNER JOIN order_items oi ON oi.order_id = o.id
        INNER JOIN products p     ON p.product_id = oi.product_id
        INNER JOIN stores   s     ON s.store_id   = o.store_id
        WHERE o.user_id = :user_id
        ORDER BY o.ordered_at DESC, o.id DESC, oi.id ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([":user_id" => $userId]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // PHP側で order_id ごとにまとめる
    $orders = [];
    foreach ($rows as $row) {
        $oid = $row["order_id"];

        if (!isset($orders[$oid])) {
            $orders[$oid] = [
                "order_id"   => (int)$row["order_id"],
                "store_id"   => $row["store_id"],
                "store_name" => $row["store_name"],
                "ordered_at" => $row["ordered_at"],
                "total"      => (int)$row["total"],
                "items"      => []
            ];
        }

        $orders[$oid]["items"][] = [
            "product_id" => (int)$row["product_id"],
            "name"       => $row["product_name"],
            "quantity"   => (int)$row["quantity"],
            "price"      => (int)$row["price"]
        ];
    }

    echo json_encode([
        "status" => "ok",
        "data"   => array_values($orders)
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    echo json_encode([
        "status"  => "error",
        "message" => "注文履歴の取得中にエラーが発生しました: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
