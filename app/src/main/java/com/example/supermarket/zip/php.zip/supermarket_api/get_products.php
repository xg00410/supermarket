<?php
ob_clean();
header("Content-Type: application/json; charset=UTF-8");
require_once __DIR__ . "/db_config.php";

// store_id / store_code どちらでも受け取れるようにする
$store_id = $_GET["store_id"] ?? $_GET["store_code"] ?? null;

if (!$store_id) {
    echo json_encode([
        "status" => "error",
        "message" => "store_id missing"
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql = "
        SELECT 
            p.product_id,
            p.name,
            p.category,
            p.price,
            p.image_name,
            sp.stock,
            sp.shelf_id,
            sp.access_point_id
        FROM products p
        JOIN store_products sp 
            ON p.product_id = sp.product_id
        WHERE sp.store_id = :store_id
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':store_id', $store_id, PDO::PARAM_STR);
    $stmt->execute();

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "ok",
        "data"   => $rows
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "SQL error: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
