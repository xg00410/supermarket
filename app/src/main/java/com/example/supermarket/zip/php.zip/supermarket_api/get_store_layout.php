<?php
// =========================================================
// get_store_layout.php
// 店舗内ナビゲーション用レイアウト取得 API
// - nav_nodes / nav_edges / shelves / shelf_access_points を取得
// - Kotlin 側の NavGraphModels に合わせて camelCase で JSON を返す
// =========================================================

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

require_once "db_config.php";

try {
    // ----------------------------
    // store_id パラメータチェック
    // ----------------------------
    if (!isset($_GET['store_id'])) {
        echo json_encode([
            "status"  => "error",
            "message" => "store_id is required"
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    $storeId = $_GET['store_id'];

    // ----------------------------
    // 1. nav_nodes
    // ----------------------------
    $sqlNodes = "
        SELECT node_id, x, y, is_entrance
        FROM nav_nodes
        WHERE store_id = :store_id
        ORDER BY node_id
    ";
    $stmtNodes = $pdo->prepare($sqlNodes);
    $stmtNodes->execute([':store_id' => $storeId]);

    $nodes = [];
    while ($row = $stmtNodes->fetch(PDO::FETCH_ASSOC)) {
        $nodes[] = [
            // Kotlin: NavNode.nodeId
            "nodeId"      => $row["node_id"],
            "x"           => (float)$row["x"],
            "y"           => (float)$row["y"],
            // Kotlin: Boolean isEntrance
            "isEntrance"  => (bool)$row["is_entrance"],
        ];
    }

    // ----------------------------
    // 2. nav_edges
    // ----------------------------
    $sqlEdges = "
        SELECT edge_id, from_node_id, to_node_id, distance
        FROM nav_edges
        WHERE store_id = :store_id
        ORDER BY edge_id
    ";
    $stmtEdges = $pdo->prepare($sqlEdges);
    $stmtEdges->execute([':store_id' => $storeId]);

    $edges = [];
    while ($row = $stmtEdges->fetch(PDO::FETCH_ASSOC)) {
        $edges[] = [
            // Kotlin: NavEdge.edgeId (Long)
            "edgeId"     => (int)$row["edge_id"],
            "fromNodeId" => $row["from_node_id"],
            "toNodeId"   => $row["to_node_id"],
            // distance は NULL なら null にする（Kotlin 側で座標から計算可）
            "distance"   => $row["distance"] !== null ? (float)$row["distance"] : null,
        ];
    }

    // ----------------------------
    // 3. shelves
    // ----------------------------
    $sqlShelves = "
        SELECT shelf_id, x, y, width, height, is_against_wall
        FROM shelves
        WHERE store_id = :store_id
        ORDER BY shelf_id
    ";
    $stmtShelves = $pdo->prepare($sqlShelves);
    $stmtShelves->execute([':store_id' => $storeId]);

    $shelves = [];
    while ($row = $stmtShelves->fetch(PDO::FETCH_ASSOC)) {
        $shelves[] = [
            "shelfId"       => $row["shelf_id"],
            "x"             => (float)$row["x"],
            "y"             => (float)$row["y"],
            "width"         => (float)$row["width"],
            "height"        => (float)$row["height"],
            "isAgainstWall" => (bool)$row["is_against_wall"],
        ];
    }

    // ----------------------------
    // 4. shelf_access_points
    // ----------------------------
    $sqlAccess = "
        SELECT access_point_id, shelf_id, x, y, nearest_node_id, side
        FROM shelf_access_points
        WHERE store_id = :store_id
        ORDER BY access_point_id
    ";
    $stmtAccess = $pdo->prepare($sqlAccess);
    $stmtAccess->execute([':store_id' => $storeId]);

    $accessPoints = [];
    while ($row = $stmtAccess->fetch(PDO::FETCH_ASSOC)) {
        $accessPoints[] = [
            "accessPointId" => $row["access_point_id"],
            "shelfId"       => $row["shelf_id"],
            "x"             => (float)$row["x"],
            "y"             => (float)$row["y"],
            "nearestNodeId" => $row["nearest_node_id"],
            "side"          => $row["side"],
        ];
    }

    // ----------------------------
    // JSON レスポンス
    // ----------------------------
    echo json_encode([
        "status"        => "ok",
        "nodes"         => $nodes,
        "edges"         => $edges,
        "shelves"       => $shelves,
        "access_points" => $accessPoints
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "レイアウト取得中にエラーが発生しました: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>
