<?php
// =========================================================
// File: get_stores.php
// 役割:
//   - stores テーブルから全店舗一覧を取得する。
//   - 今は都道府県ID列は使わず、住所文字列で判定する方針。
// =========================================================

require_once "db_config.php";

header("Content-Type: application/json; charset=utf-8");

try {
    $sql = "
        SELECT
            store_id,
            name,
            address,
            latitude,
            longitude
        FROM stores
        ORDER BY store_id
    ";
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "ok",
        "data"   => $rows
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "店舗情報の取得中にエラーが発生しました: " . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
