<?php
require_once "db_config.php";

header("Content-Type: application/json; charset=utf-8");

// --------------------------------------------------
// JSON 受信
// --------------------------------------------------
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

$userId   = $data["user_id"]   ?? null;  // Kotlin 側の InsertOrderBody.user_id
$storeId  = $data["store_code"] ?? null; // InsertOrderBody.store_code → "S001" など
$items    = $data["items"]     ?? null;  // [{product_id, quantity, price}, ...]

if (!$userId || !$storeId || !is_array($items) || count($items) === 0) {
    echo json_encode([
        "status"  => "error",
        "message" => "不正なリクエストです。"
    ]);
    exit;
}

// --------------------------------------------------
// 合計金額を計算
// --------------------------------------------------
$totalAmount = 0;
foreach ($items as $item) {
    $price    = isset($item["price"])    ? (int)$item["price"]    : 0;
    $quantity = isset($item["quantity"]) ? (int)$item["quantity"] : 0;
    $totalAmount += $price * $quantity;
}

try {
    $pdo->beginTransaction();

    // --------------------------------------------------
    // orders テーブルに1件登録
    //   - store_id は "S001" などの文字列
    // --------------------------------------------------
    $sqlOrder = "INSERT INTO orders (user_id, store_id, total, ordered_at)
                 VALUES (:user_id, :store_id, :total, NOW())";
    $stmtOrder = $pdo->prepare($sqlOrder);
    $stmtOrder->bindParam(":user_id",  $userId,  PDO::PARAM_INT);
    $stmtOrder->bindParam(":store_id", $storeId, PDO::PARAM_STR);
    $stmtOrder->bindParam(":total",    $totalAmount, PDO::PARAM_INT);
    $stmtOrder->execute();

    $orderId = $pdo->lastInsertId();

    // --------------------------------------------------
    // order_items テーブルに明細を複数件登録
    // --------------------------------------------------
    $sqlItem = "INSERT INTO order_items (order_id, product_id, quantity, price)
                VALUES (:order_id, :product_id, :quantity, :price)";
    $stmtItem = $pdo->prepare($sqlItem);

    foreach ($items as $item) {
        $productId = (int)$item["product_id"];
        $quantity  = (int)$item["quantity"];
        $price     = (int)$item["price"];

        $stmtItem->bindParam(":order_id",   $orderId,  PDO::PARAM_INT);
        $stmtItem->bindParam(":product_id", $productId, PDO::PARAM_INT);
        $stmtItem->bindParam(":quantity",   $quantity,  PDO::PARAM_INT);
        $stmtItem->bindParam(":price",      $price,     PDO::PARAM_INT);
        $stmtItem->execute();
    }

    $pdo->commit();

    echo json_encode([
        "status"   => "ok",
        "order_id" => $orderId
    ]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        "status"  => "error",
        "message" => "注文登録中にエラーが発生しました: " . $e->getMessage()
    ]);
}
