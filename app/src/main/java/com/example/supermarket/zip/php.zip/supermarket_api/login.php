<?php
// login.php
// 役割: フロントから user_code（＝DBの userid）と password を受け取り、ログイン判定を行う。
//       成功時は Kotlin 側が期待している JSON 形式でユーザー情報を返す。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

// フロントから来るキー名は user_code / password
// DB 上のカラム名は userid / password / username
$user_code = trim($input['user_code'] ?? '');
$password  = trim($input['password']  ?? '');

if ($user_code === '' || $password === '') {
    echo json_encode([
        'status'    => 'error',
        'id'        => null,
        'user_id'   => null,
        'user_code' => null,
        'name'      => null,
        'phone'     => null,
        'email'     => null,
        'message'   => 'ユーザーIDとパスワードを入力してください。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // DB の users テーブル構造（supermarket.sql より）:
    // id, userid, password, username, gender, phone, email
    $sql = "
        SELECT id, userid, password, username, phone, email
          FROM users
         WHERE userid = ?
         LIMIT 1
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_code]);

    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        echo json_encode([
            'status'    => 'error',
            'id'        => null,
            'user_id'   => null,
            'user_code' => null,
            'name'      => null,
            'phone'     => null,
            'email'     => null,
            'message'   => 'ユーザーが見つかりません。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // パスワードチェック（今は平文比較。ハッシュ化するなら password_verify を使う）
    if ($row['password'] !== $password) {
        echo json_encode([
            'status'    => 'error',
            'id'        => null,
            'user_id'   => null,
            'user_code' => null,
            'name'      => null,
            'phone'     => null,
            'email'     => null,
            'message'   => 'パスワードが違います。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // Kotlin 側の ApiResponse が期待しているキー名に合わせて返す
    echo json_encode([
        'status'    => 'ok',
        'id'        => (int)$row['id'],
        'user_id'   => (int)$row['id'],
        'user_code' => $row['userid'],      // DB: userid → JSON: user_code
        'name'      => $row['username'],    // DB: username → JSON: name
        'phone'     => $row['phone'],
        'email'     => $row['email'],
        'message'   => 'ログイン成功'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'ログイン中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
