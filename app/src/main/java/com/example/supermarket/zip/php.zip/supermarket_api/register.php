<?php
// register.php
// 役割: 新規会員登録。
//       フロントから受け取る user_code / name は、DB 上では userid / username に保存する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

// フロントから送られてくる値（Kotlin の RegisterBody）
$user_code = trim($input['user_code'] ?? '');  // DB: users.userid
$password  = trim($input['password']  ?? '');
$email     = isset($input['email']) ? trim($input['email']) : null;
$name      = isset($input['name'])  ? trim($input['name'])  : null; // DB: users.username
$phone     = isset($input['phone']) ? trim($input['phone']) : null;

if ($user_code === '' || $password === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDとパスワードは必須です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // 既に同じ userid が存在しないか確認
    $checkSql = "SELECT id FROM users WHERE userid = ?";
    $checkStmt = $pdo->prepare($checkSql);
    $checkStmt->execute([$user_code]);
    if ($checkStmt->fetch()) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'このユーザーIDは既に使用されています。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // users テーブル構造:
    // id, userid, password, username, gender, phone, email
    $insertSql = "
        INSERT INTO users (userid, password, username, phone, email)
        VALUES (?, ?, ?, ?, ?)
    ";
    $stmt = $pdo->prepare($insertSql);

    // 今はパスワードを平文保存（必要に応じて password_hash へ変更可）
    $stmt->execute([$user_code, $password, $name, $phone, $email]);

    echo json_encode([
        'status'  => 'ok',
        'message' => '登録が完了しました。'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => '登録中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
