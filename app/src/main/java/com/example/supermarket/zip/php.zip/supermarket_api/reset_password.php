<?php
// reset_password.php
// 役割: ユーザーID + メールアドレスを確認し、新しいパスワードに更新する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_code    = trim($input['user_code']    ?? '');  // DB: userid
$email        = trim($input['email']        ?? '');
$new_password = trim($input['new_password'] ?? '');

if ($user_code === '' || $email === '' || $new_password === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'すべての項目を入力してください。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    // userid + email でユーザー存在確認
    $sql = "SELECT id, email FROM users WHERE userid = ? LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_code]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row || $row['email'] !== $email) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'ユーザーIDまたはメールアドレスが一致しません。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    // パスワード更新
    $updateSql = "UPDATE users SET password = ? WHERE id = ?";
    $updateStmt = $pdo->prepare($updateSql);
    $updateStmt->execute([$new_password, $row['id']]);

    echo json_encode([
        'status'  => 'ok',
        'message' => 'パスワードを更新しました。'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => '更新中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
