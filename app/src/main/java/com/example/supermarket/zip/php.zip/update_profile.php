<?php
// update_profile.php
// 役割: ログイン中ユーザーの氏名・電話番号・メールを更新する。
//       Kotlin 側からは name / phone / email が送られてくるが、
//       DB 上では username に保存する。

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_id = (int)($input['user_id'] ?? 0);
$name    = isset($input['name'])  ? trim($input['name'])  : null; // DB: username
$phone   = isset($input['phone']) ? trim($input['phone']) : null;
$email   = isset($input['email']) ? trim($input['email']) : null;
// 空文字は NULL 扱いに統一（DBの整合性維持）
$name  = ($name === '')  ? null : $name;
$phone = ($phone === '') ? null : $phone;
$email = ($email === '') ? null : $email;

// メール：必須・長さ・形式チェック（users.email: varchar(100)）
if ($email === null) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'メールアドレスを入力してください。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}
if (strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'メールアドレスの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 電話番号：任意（入力がある場合のみチェック）
if ($phone !== null) {
    // 数字とハイフンのみ（例: 090-1234-5678）
    if (strlen($phone) > 30 || !preg_match('/^[0-9-]+$/', $phone)) {
        echo json_encode([
            'status'  => 'error',
            'message' => '電話番号の形式が不正です。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

if ($user_id <= 0) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDが不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql = "
        UPDATE users
           SET username = ?, phone = ?, email = ?
         WHERE id = ?
    ";
$stmt = $pdo->prepare($sql);
$stmt->execute([$name, $phone, $email, $user_id]);

// 更新対象が存在しない場合（0件更新）はエラー扱い
if ($stmt->rowCount() === 0) {
    echo json_encode([
        'status'  => 'error',
        'message' => '更新対象のユーザーが見つかりません。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode([
    'status'  => 'ok',
    'message' => 'プロフィールを更新しました。',
    'user_id' => $user_id,
    'name'    => $name,
    'phone'   => $phone,
    'email'   => $email
], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => '更新中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
