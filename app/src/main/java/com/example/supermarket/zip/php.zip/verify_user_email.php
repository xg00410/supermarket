<?php
// verify_user_email.php
// 役割: ユーザーID + メールアドレスが一致するか確認する（パスワード更新はしない）

require_once 'db_config.php';

$input = json_decode(file_get_contents('php://input'), true);

$user_code = trim($input['user_code'] ?? '');
$email     = trim($input['email'] ?? '');

if ($user_code === '' || $email === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'すべての項目を入力してください。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// 英数字のみ・長さチェック（userid: varchar(50)）
if (!preg_match('/^[a-zA-Z0-9]+$/', $user_code) || strlen($user_code) > 50) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'ユーザーIDの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// メール形式・長さチェック（email: varchar(100)）
if (strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode([
        'status'  => 'error',
        'message' => 'メールアドレスの形式が不正です。'
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $sql = "SELECT id, email FROM users WHERE userid = ? LIMIT 1";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$user_code]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row || $row['email'] !== $email) {
        echo json_encode([
            'status'  => 'error',
            'message' => 'ユーザーIDまたはメールアドレスが一致しません。'
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode([
        'status'  => 'ok',
        'message' => '確認成功'
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => '確認中にエラーが発生しました: ' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
