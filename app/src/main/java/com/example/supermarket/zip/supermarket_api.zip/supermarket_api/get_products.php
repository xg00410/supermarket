<?php
require_once "db_config.php";

header("Content-Type: application/json; charset=utf-8");

// GET パラメータ: store_code=S001 など
$storeId = $_GET["store_code"] ?? null;

if (!$storeId) {
    echo json_encode([
        "status"  => "error",
        "message" => "store_code が指定されていません。"
    ]);
    exit;
}

try {
    // DB 構造:
    //   products(product_id, name, category, price)
    //   store_products(id, store_id, product_id, stock)
    //
    // 目的:
    //   ある店舗(store_id)に紐づく商品一覧 + 在庫数(stock) を取得する。
    $sql = "
        SELECT 
            p.product_id,
            p.name,
            p.category,
            p.price,
            sp.stock
        FROM store_products sp
        INNER JOIN products p
            ON sp.product_id = p.product_id
        WHERE sp.store_id = :store_id
        ORDER BY p.product_id ASC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(":store_id", $storeId, PDO::PARAM_STR);
    $stmt->execute();

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "ok",
        "data"   => $rows
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status"  => "error",
        "message" => "商品取得中にエラーが発生しました: " . $e->getMessage()
    ]);
}
